<?php

include 'koneksi.php';

header('Content-Type: application/json');

$response = [
    'success' => false,
    'message' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $kode  = $_POST['kode_mobil'] ?? '';
    $merk  = $_POST['merk'] ?? '';
    $tipe  = $_POST['type'] ?? '';
    $warna = $_POST['warna'] ?? '';
    $harga = $_POST['harga'] ?? '';

    if ($kode && $merk && $tipe && $warna && $harga) {

        if (!is_numeric($harga)) {

            $response['message'] = "Harga harus berupa angka!";

        } else {

            $stmt = $conn->prepare(
                "INSERT INTO mobil (kode_mobil, merk, type, warna, harga)
                 VALUES (?, ?, ?, ?, ?)"
            );

            $stmt->bind_param(
                "ssssi",
                $kode,
                $merk,
                $tipe,
                $warna,
                $harga
            );

            $response['success'] = $stmt->execute();

            $response['message'] = $response['success']
                    ? "Data berhasil disimpan"
                    : "Gagal menyimpan data: " . $stmt->error;

            $stmt->close();
        }

    } else {

        $response['message'] = "Semua data wajib diisi!";
    }

} else {

    $response['message'] = "Metode Request Tidak Valid";
}

echo json_encode($response);

?>  